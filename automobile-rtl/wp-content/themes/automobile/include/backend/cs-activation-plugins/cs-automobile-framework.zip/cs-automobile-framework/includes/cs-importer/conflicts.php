<?php
$conflicted_pages = array(
	"automobile" => array(
		"About Us",
		"Home",
	),
);